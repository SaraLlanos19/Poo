
package ProyectoFinal;

public class MangaException extends Exception {
     public MangaException() {
        super ("No se puede añadir la blusa Manga Larga al almacén");
    } 
    
}
