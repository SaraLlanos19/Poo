
package ProyectoFinal;

public class IdException extends Exception {
    public IdException() {
        super ("El id no es válido");
    }
}
