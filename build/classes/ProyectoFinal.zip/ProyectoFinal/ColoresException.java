
package ProyectoFinal;

public class ColoresException extends Exception{
    
    public ColoresException(){
        super("Los colores no son válidos");
        
    }
    
}
