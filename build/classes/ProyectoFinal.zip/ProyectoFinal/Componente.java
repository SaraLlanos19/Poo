
package ProyectoFinal;

import java.io.Serializable;

public class Componente implements Serializable{
    //Atributos
    private int id;
    private String nombre;
    private String talla;
    private String color;
    private boolean esComunitario;
    private double precio;
    //Constructor
    public Componente(int id, String nombre, String talla, String color, boolean escomunitario, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.talla = talla;
        this.color = color;
        this.esComunitario = escomunitario;
        this.precio = precio;
    }//GetySet
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getTalla() {
        return talla;
    }
    public void setTalla(String talla) {
        this.talla = talla;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public boolean isEscomunitario() {
        return esComunitario;
    }
    public void setEscomunitario(boolean escomunitario) {
        this.esComunitario = escomunitario;
    }
    public double getPrecio() {
        return precio;
    }
    public void setPrecio(double precio) {
        this.precio = precio;
    }//toString
    @Override
    public String toString() {
        return "Componente{" + "Id: " + id + ", Nombre: " + nombre + ", Talla: " + talla + ", Color: " + color + ", Es Comunitario: " + esComunitario + ", Precio: " + precio + '}';
    }//equals

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Componente other = (Componente) obj;
        return this.id == other.id;
    }

    public int compareTo(Componente componente) {
        return Integer.compare(this.id, componente.getId());
    }

    
    
}
