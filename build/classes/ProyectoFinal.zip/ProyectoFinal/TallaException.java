
package ProyectoFinal;

public class TallaException extends Exception {
    public TallaException(){
        super("La Talla no es válida");
    }
    
    
}
