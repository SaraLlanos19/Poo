
package ProyectoFinal;

public class DemasiadosComunitarioException extends Exception{
    public DemasiadosComunitarioException() {
        super ("No se pudo añadir el componente");
    }
}
